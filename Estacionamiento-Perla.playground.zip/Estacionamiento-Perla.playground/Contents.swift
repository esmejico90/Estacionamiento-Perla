import Foundation

func getPriceForMinutes(time: Int) -> String {
        var price = 0
    let timePerHour = time > 180 ? 8 : 10
    let fraccion = 6
        switch time {
        case 1...60:
            if time < 60 {
                price = fraccion
            } else {
                price = timePerHour
            }
            return "\(price)"
        default:
            if time == 0 {
                return "EL precio es 0"
            }
            let result = getNumberOfHours(time: time)
            if result.0 > 0 {
                price = result.0 * timePerHour
            }
            if result.1 > 0 {
                price = price + fraccion
            }
            return "\(price)"
        }
    }

    func getNumberOfHours(time: Int) -> (Int, Int) {
        var hours = 0
        var minutos = time
        
        while minutos >= 60 {
            hours += 1
            minutos = minutos - 60
        }
        
        return (hours, minutos)
    }
    
    var minutos = 185
    let price = getPriceForMinutes(time: minutos)
    print(price)

